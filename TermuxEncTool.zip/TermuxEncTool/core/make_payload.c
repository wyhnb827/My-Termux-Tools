#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "用法: %s <文件>\n", argv[0]);
        return 1;
    }

    FILE *f = fopen(argv[1], "rb");
    if (!f) {
        perror("打开文件失败");
        return 1;
    }

    fseek(f, 0, SEEK_END);
    long len = ftell(f);
    fseek(f, 0, SEEK_SET);

    unsigned char *buf = malloc(len);
    fread(buf, 1, len, f);
    fclose(f);

    // 生成随机密钥
    srand(time(NULL));
    unsigned char key = rand() % 255 + 1; 

    // XOR加密
    for (long i = 0; i < len; i++)
        buf[i] ^= key;

    
    FILE *out = fopen("payload.h", "w");
    if (!out) {
        perror("写入 payload.h 失败");
        free(buf);
        return 1;
    }

    fprintf(out, "#ifndef PAYLOAD_H\n#define PAYLOAD_H\n\n");
    fprintf(out, "#include <stddef.h>\n\n");
    fprintf(out, "static const unsigned char XOR_KEY = %u;\n", key);
    fprintf(out, "static const size_t code_len = %ld;\n", len);
    fprintf(out, "static const unsigned char code_data[] = {\n    ");

    for (long i = 0; i < len; i++) {
        fprintf(out, "%d", buf[i]);
        if (i < len - 1)
            fprintf(out, ", ");
        if ((i + 1) % 16 == 0)
            fprintf(out, "\n    ");
    }
    fprintf(out, "\n};\n\n#endif // PAYLOAD_H\n");

    fclose(out);
    free(buf);
    return 0;
}
