
# Termux Simple Encrypt / TermuxEncTool

一个轻量级的运行时加壳工具，使用 XOR 加密和 xorstr 字符串加密库，保护你的可执行文件。

A lightweight runtime packer that protects your executables using XOR encryption and the xorstr string encryption library.

---

## 文件结构 / File Structure

TermuxEncTool/
├── protect.sh          # 主加密脚本 / Main encryption script
├── core/               # 核心文件目录 / Core files directory
│   ├── xorstr.hpp      # 字符串加密库 / String encryption library
│   ├── make_payload.c  # XOR 加密工具源码 / XOR encryption tool source
│   └── stub.cpp        # 运行时解密壳源码 / Runtime decryption stub source
└── README.md           # 本说明文件 / This readme



## 使用方法 / Usage

### 中文
1. **准备环境**
   确保已安装 `clang` 编译器（Termux 中执行 `pkg install clang`）。

2. **加密你的程序**
   chmod +x protect.sh
   ./protect.sh 你的程序   # 例如 ./protect.sh hello

1. 运行加密后的程序
   ./protected
2. 清理
   每次加密会自动生成临时文件（make_payload、payload.h），脚本执行完毕后自动删除。最终成品为 ./protected。

English

1. Prerequisites
   Make sure clang compiler is installed (in Termux: pkg install clang).
2. Encrypt your program
   chmod +x protect.sh
   ./protect.sh your_program   # e.g. ./protect.sh hello
3. Run the protected program
   ./protected
4. Cleanup
   Temporary files (make_payload, payload.h) are automatically deleted after encryption. The final packed program is ./protected.


注意事项 / Notes

· 所有提示字符串在编译时被加密，二进制文件中不可见。
  All prompt strings are encrypted at compile time and are not visible in the binary.
· XOR 密钥随机生成，每次加密不同。
  XOR key is randomly generated and differs each time.
· 仅支持 Termux 或类 Unix 环境（需要 clang 和标准工具链）。
  Only supported on Termux or Unix-like environments (requires clang and standard toolchain)