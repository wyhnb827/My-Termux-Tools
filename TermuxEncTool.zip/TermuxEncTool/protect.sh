#!/bin/bash

echo "╔════════════════════════╗"
echo "║  Termux Simple Encrypt ║"
echo "╚════════════════════════╝"
echo ""

if [ $# -ne 1 ]; then
    echo "用法: $0 <原始程序>"
    exit 1
fi

if ! command -v clang &> /dev/null; then
    echo "错误: 未找到 clang，请安装 clang 编译器"
    exit 1
fi

TARGET="$1"
if [ ! -f "$TARGET" ]; then
    echo "错误: 文件 $TARGET 不存在"
    exit 1
fi

if [ ! -d core ]; then
    echo "错误: 缺少 core/ 子目录"
    exit 1
fi

if [ ! -f core/xorstr.hpp ]; then
    if [ -f ~/xorstr.hpp ]; then
        cp ~/xorstr.hpp core/
    else
        echo "错误: 找不到 xorstr.hpp"
        exit 1
    fi
fi

echo "[1/4] 编译 make_payload"
clang core/make_payload.c -o make_payload || { echo "编译 make_payload 失败"; exit 1; }

# 切换到当前目录执行加密（payload.h 生成在当前目录）
echo "[2/4] 加密 $TARGET"
./make_payload "$TARGET" || { echo "加密失败"; exit 1; }

# 编译 stub.cpp，需要包含当前目录（存放 payload.h）和 core 目录（存放 xorstr.hpp）
echo "[3/4] 编译 stub.cpp"
clang++ -std=c++17 -I. -Icore core/stub.cpp -o protected || { echo "编译 stub 失败"; exit 1; }

echo "[4/4] 清理临时文件"
rm -f make_payload payload.h

echo "成功生成: ./protected"
echo "运行: ./protected"